/*
    Written by Brandon Atwal, Owais Ashraf, Anthony Chen, and Jacob Danel
    NetIDs: BSA190001, OXA200003, JCD190000, AJC200002
    for CS 4485, Mobile Attendance App, starting February 10, 2023.

    This mobile app connects with Professor Cole's Attend desktop app over Bluetooth,
    and allows students to sign in by swiping their comet card via a card scanner peripheral.

    Both the mobile device running this app and the desktop app running Attend must have Bluetooth capabilities.
    The mobile device running this app must already be paired to the desktop device running Attend.
    The mobile device running this app should have a card scanner peripheral connected to it
    so that students can swipe their comet cards.

    Once Attend is running and has the desired class open for attendance, launch this app.
    It will automatically connect to Attend, and prompt the user when it's ready to accept comet cards.
    Once it is connected, students can swipe their comet cards to sign it.
    Successful sign-ins will be sent to Attend. Unsuccessful sign-ins will be prompted
    to swipe again or speak to their Professor.
 */
package com.example.attendance_63;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;

//import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.pm.PackageManager;
//import android.nfc.Tag;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
//import android.os.ParcelUuid;
import android.os.Handler;
import android.os.ParcelUuid;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
//import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
//import java.util.List;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/*  Main activity class handling app UI and functionality.
    Written by Brandon Atwal, Jacob Danel, Anthony Chen, and Owais Ashraf.
    More specification on who wrote specific functions found by their respective functions.
 */
@RequiresApi(api = Build.VERSION_CODES.S)
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final ToneGenerator toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
    private BluetoothAdapter bluetoothAdapter;
    private final ArrayList<BluetoothDevice> deviceList = new ArrayList<>();

    private final UUID uuid = UUID.fromString("e0cbf06c-cd8b-4647-bb8a-263b43f0f974"); //UUID to connect to Attend
    private BluetoothSocket socket;
    private static final String[] PERMISSIONS_STORAGE = {
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT,
            android.Manifest.permission.BLUETOOTH_PRIVILEGED
    };
    private static final String[] PERMISSIONS_LOCATION = {
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT,
            android.Manifest.permission.BLUETOOTH_PRIVILEGED
    };

    Handler statusUpdater = new Handler();
    TextView tvStatus;
    TextView tvListStatus;   //this will be the textview that holds the *id* list when we get it
    TextView tvLastIDSubmitted;    //text view that holds the last id submitted to Attend
    EditText etTxtID; //the Edit Text that will be keyed into for user input
    TextView tvDebug; // textview of debugging text

    ArrayList<Byte> inputBytes = new ArrayList<>();
    ArrayList<String> stringIDs = new ArrayList<>();
    BluetoothDevice device;

    long startTime = 0;         //start time set to disabled initially
    int partialCardReads = 0;    //number of consecutive failed card reads
    boolean timerRunning = false;
    boolean refocusCalled = false;
    Handler timerHandler = new Handler(); //manages whether the timer is enabled or disabled

    /*  Manages timer when enabled
        Written by Anthony Chen */
    Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            //only run timer if enabled
            if(startTime != 0) {
                //get time passed since timer enabled
                long millis = System.currentTimeMillis() - startTime;
                Log.i(TAG, "Its been " + millis + " millis since the timer started");

                //auto submit EditText input with toast message when 1s has passed since timer enabled
                if(millis >= 1000) {
                    submitID(" was submitted due to a detected partial card read.");
                }

                if(timerRunning) {
                    timerHandler.postDelayed(this, 500);
                }
                else {
                    timerHandler.removeCallbacks(this);
                }
            }
        }
    };


    /*  When the activity is initialized, initialize Bluetooth and UI
        Written by Jacob Danel, Anthony Chen, and Owais Ashraf
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //auto generated permissions check that uses the checkPermissions function to make these more generic/not copy and paste the same code over and over
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
        }

        //initialize the BluetoothAdapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //Grab the Status TextView
        tvStatus = (TextView) findViewById(R.id.tvStatus);

        tvListStatus = (TextView) findViewById(R.id.tvListDisplay);

        //Grab last Id submitted TextView
        tvLastIDSubmitted = (TextView) findViewById(R.id.tvLastIDSubmitted);

        tvDebug = (TextView) findViewById(R.id.bugger);


        //attach a listener to the text input field
        etTxtID = (EditText) findViewById(R.id.txtID);
        etTxtID.requestFocus();
        etTxtID.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void afterTextChanged(Editable editable) {
                if(refocusCalled) {
                    refocusCalled = false;
                }
                else {
                    Log.i(TAG, "After Text Changed");

                    //start timer
                    startTime = System.currentTimeMillis();

                    //Start a new timer thread only if timer was not already running
                    if(!timerRunning) {
                        timerRunning = true;
                        timerHandler.postDelayed(timerRunnable, 0);
                        Log.i(TAG, "Timer Started");
                    }

                    tvDebug.setText(((TextView)findViewById(R.id.txtID)).getText().toString() + "\na");

                    //auto submitt when there is something in EditText and it ends with a newline char
                    if(editable.length() != 0 && editable.charAt(editable.length()-1) == '\n') {
                        //submit the ID with the given toastMessage
                        submitID(" was marked present");
                    }
                }
            }
        });

        connectToBluetoothDevice();  //connect to bluetooth via thread
    }

    /*  When button is pressed, submits ID in text field
        Written by Brandon Atwal
    */
    public void onButtonPress(View v) throws IOException {
        submitID(" was submitted because a button was pressed");
    }

    /* Function to submit ID.
        Submits the ID in the txtID object with a Toast Message,
        updates lastIDSubmitted TextView, clears the txtID and refocuses
        on it to receive next ID. then sends the ID to validation.

        Written by Anthony Chen and Jacob Danel
     */
    private void submitID(String toastMessage) {
        // disable timer when an ID is submitted it will be re-enabled when
        timerRunning = false;
        startTime = 0;
        timerHandler.removeCallbacks(timerRunnable);
        refocusCalled = true;
        Log.i(TAG, "Timer Stopped");

        String input = ((TextView)findViewById(R.id.txtID)).getText().toString() + '\n';

        tvLastIDSubmitted.setText(input);

        //reset box and refocus it
        ((TextView)findViewById(R.id.txtID)).setText("");
        etTxtID.requestFocus();

        validateID(input, toastMessage);
    }


    /* Starts a thread to validate the ID
        Written by Anthony Chen
     */
    private void validateID(String input, String toastMessage){
        //create CheckThread object and start the thread to process the ID submitted and potentially send it to Attend
        try {
            new CheckThread(device, input, toastMessage).start();
            Log.i(TAG, "CheckThread with ID: " + input + " was created.");
        } catch (Exception e) {
            Log.i(TAG, "Failed to start CheckThread.");
        }
    }


    /*  Initializes the connection with Desktop device over Bluetooth.
        Discovers paired devices and searches for a device with the desired UUID.
        Written by Jacob Danel and Brandon Atwal
     */
    private void connectToBluetoothDevice(){
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
        }
        //request bluetooth perms
        checkPermissions();

        //Call a function that starts discovery of nearby bluetooth devices
        startDiscovery();

        //Get a list of all devices that have been paired to this device over Bluetooth
        Set<BluetoothDevice> pairedDevs = bluetoothAdapter.getBondedDevices();

        //Search the paired devices for one that is advertising the desired UUID
        for(BluetoothDevice dev : pairedDevs){
            dev.fetchUuidsWithSdp();
            ParcelUuid[] uuids = dev.getUuids();

            if(uuids != null){
                for (ParcelUuid uuidIter : uuids){
                    if(uuid.equals(uuidIter.getUuid())){
                        device = dev; //save the device for creating new CheckThread each time OnButtonPressed(View v) is called

                        //Create a thread to handle connection initialization so that UI thread is not tied up.
                        try {
                            ConnectThread connectSock = new ConnectThread(dev);
                            bluetoothAdapter.cancelDiscovery();
                            connectSock.start();
                            break;
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }
    }

    /* Puts app in pause state until its brought back to the foreground by the user, switch to resume state
        Written by Jacob Danel and Anthony Chen
     */
    @Override
    protected void onPause() {
        super.onPause();

        startTime = 0;
        timerHandler.removeCallbacks(timerRunnable);
    }

    /* Unregisters the deviceReceiver upon closing the app
        Written by Jacob Danel
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    /*  Essentially this is the startDiscovery function of the BluetoothAdapter class with added functionality
        where we check if the create instance of the BluetoothAdapter is null, if bluetooth is already enabled on the device
        and if not request that it be turned on, and to stop discovery if it is already running. Once those are all checked
        we start the discovery process.
        Written by Jacob Danel
    * */
    public void startDiscovery() {
        //auto generated permissions check that uses the checkPermissions() function to make these more generic/not copy and paste the same code over and over
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
        }
        //clear the device list and notify the adapter of the changes, should probably add this to the itemClick as well
        deviceList.clear();
        //listAdapter.notifyDataSetChanged();

        //check if bluetooth is available and enabled
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is unavailable on this device", Toast.LENGTH_SHORT).show();
            return;

        } else if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
            return;
        }

        //if it was already in discovery mode before, stop it before we start discovery again
        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        //start the device discovery process so we can populate the list
        bluetoothAdapter.startDiscovery();
    }

    /*  Check permissions necessary for app functionality.
        Request permissions if needed.
        Written by Jacob Danel
     */
    private void checkPermissions() {
        int permission1 = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permission2 = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN);

        //if we don't have permissions, prompt the user to grant permission
        if (permission1 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, 1);
        } else if (permission2 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, PERMISSIONS_LOCATION, 1);
        }
    }




    /* The thread that initializes the connection with Attend.
        Establishes the socket connection then retrieves the list of
        Student ID strings from Attend.
        Written by Brandon Atwal, Jacob Danel, and Anthony Chen
     */
    private class ConnectThread extends Thread {

        /* Initialization of thread bluetooth socket.
            Written by Jacob Danel
         */
        public ConnectThread(BluetoothDevice device) throws IOException {
            BluetoothSocket tmp = null;
            //auto generated permissions check that uses the checkPermissions function to make these more generic/not copy and paste the same code over and over
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                checkPermissions();
            }

            try {
                //get a bluetoothSocket to connect with the given BluetoothDevice, more specifically the app associated with the bluetooth device
                tmp = device.createRfcommSocketToServiceRecord(uuid);
            } catch (IOException e) {
                Log.e(TAG, "Creation of socket failed", e);
            }
            socket = tmp;
        }

        /* Establishes connection with app if its valid and then runs manageConnectedSocket function
            Runs when start() is called on the client socket variable
            Written by Brandon Atwal, Anthony Chen
         */
        public void run() {
            //auto generated permissions check that uses the checkPermissions function to make these more generic/not copy and paste the same code over and over
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                checkPermissions();
            }

            //cancel discovery because it will slow down the connection
            if(bluetoothAdapter.isDiscovering()){
                bluetoothAdapter.cancelDiscovery();
            }


            try {
                //connect to the remote device through the socket. This call blocks
                //until it succeeds or throws an exception
                socket.connect();
                if(socket.isConnected()) {
                    Log.i(TAG, "Connection successfully made with UUID: " + uuid.toString());

                    //request a list of IDs from the desktop app
                    manageConnectedSocket(socket, "*ID*");

                    //get the list from input buffer.
                    InputStream inStream = socket.getInputStream();
                    //OutputStream outputStream = socket.getOutputStream();
                    boolean isReceiving = true;
                    while (isReceiving) //previously inStream.available() > 0)
                    {
                        int inStreamByteCount = inStream.available();
                        byte[] testInputBytes = new byte[inStreamByteCount];
                        inStream.read(testInputBytes, 0, inStreamByteCount);
                        List<Byte> syncedInputBytes =  Collections.synchronizedList(inputBytes);
                        synchronized (syncedInputBytes){
                            for (byte b : testInputBytes){
                                syncedInputBytes.add(b);
                                System.out.println(b + " ");
                                if (b == 42){   //if receive a ASCII * character, the bluetooth device is done sending.
                                    isReceiving = false;
                                }
                            }
                        }
                    }


                    //Iterate through synced list of input bytes to convert them into strings
                    List<Byte> syncedInputBytes =  Collections.synchronizedList(inputBytes);
                    List<String> syncedIDStrings = Collections.synchronizedList(stringIDs);
                    Log.i(TAG, syncedInputBytes.toString());
                    synchronized (syncedInputBytes){
                        String currentID = "";
                        for (Byte b : syncedInputBytes){
                            if (b.byteValue() == 10){
                                synchronized (syncedIDStrings){
                                    syncedIDStrings.add(currentID);
                                }
                                currentID = "";
                            }else{
                                currentID += (char)b.byteValue();
                            }
                        }
                    }

                    //Notify user that connection has been established and display IDs in the UI
                    statusUpdater.post(new Runnable() {
                        @Override
                        public void run(){
                            tvStatus.setText("Bluetooth Connection Established.\nSwipe Comet Card when ready.");
                            synchronized (syncedIDStrings){
                                tvListStatus.setText(syncedIDStrings.toString());
                            }
                            Log.i(TAG, "UI Updated with results of *ID*. Ready for input.");
                        }
                    });
                }
            } catch (IOException e) {
                //unable to connect, close the socket and return.
                Log.e(TAG, "Error connecting to device: " + e.getMessage());
                try {
                    socket.close();
                    Log.e(TAG, "Connection closed prematurely");
                } catch (IOException e2) {
                    Log.e(TAG, "Unable to close the client socket", e2);
                }
                connectionFailed();
            }

        }

        /*Notify the user that connection failed.
            Written by Brandon Atwal
         */
        private void connectionFailed(){
            statusUpdater.post(new Runnable() {
                @Override
                public void run(){
                    tvStatus.setText("Failed to connect via bluetooth. Restart both apps and try again. Start Attend before this app.");
                    Log.i(TAG, "Updated UI: Failed.");
                }
            });
        }
    }


    /*  Checks if an ID is present in the list of IDs retrieved from Attend
        Written by Anthony Chen. Some modification made by Brandon Atwal
     */
    private class CheckThread extends Thread {
        private String cardContents;    //The string of characters read from the comet card.
        private String toastMessage;    //A message indicating toast type

        public CheckThread(BluetoothDevice device, String cardContents, String toastMessage) throws IOException {
            //want the View to be able to easily clear the field when the
            this.cardContents = cardContents;
            this.toastMessage = toastMessage;
        }

        /* See if any ID retrieved from Attend is contained in the comet card String
        Written by Anthony Chen. Some modification made by Brandon Atwal
         */
        public void run() {
            //auto generated permissions check that uses the checkPermissions function to make these more generic/not copy and paste the same code over and over
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                checkPermissions();
            }
            //cancel discovery because it will slow down the connection
            if (bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
            }

            try {
                //connect to the remote device through the socket. This call blocks
                //until it succeeds or throws an exception
                if (socket.isConnected()) {
                    boolean IDFound = false;

                    //check the list of Id's given by Attend against the submitted id, if any of them are present within the submitted id then attempt to send it to Attend.
                    for (String x : stringIDs) {
                        Log.i(TAG, "Checking ID: " + x);

                        if(cardContents.contains(x)) {
                            Log.i(TAG, cardContents + " Has a valid id in it.");

                            try{
                                manageConnectedSocket(socket, cardContents);   //attempt to send the submitted ID to the Attend app
                            } catch (IOException e) {

                                //unable to connect, close the socket and return.
                                Log.e(TAG, "Error connecting to device: " + e.getMessage());
                                try {
                                    socket.close();
                                    Log.i(TAG, "Connection closed prematurely");

                                } catch (IOException e2) {
                                    Log.e(TAG, "Unable to close the client socket", e2);
                                }
                                connectionInterrupted();
                            }
                            IDFound = true;
                            break;
                        }
                    }

                    //Determine message based on whether ID was found
                    if(!IDFound){
                        Log.i(TAG, "Failed to find ID in the list");
                        toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP2);
                        toneGenerator.stopTone();

                        //choose a different failure message depending on if the card scanner had a partial read
                        if (toastMessage.contains("partial"))   //the card read was a partial read
                        {
                            //choose a different failure msg depending on number of failed consecutive partial reads
                            if (partialCardReads < 3)
                            {
                                toastMessage = "Partial read on card scanner. Please swipe again.";
                            }
                            else{
                                toastMessage = "Card read failed. Please see Professor.";
                            }
                            partialCardReads++;
                        }
                        else{       //the card read was not a partial read, but ID was not found
                            toastMessage = "ID not found. See Professor.";
                            partialCardReads = 0;
                        }

                    }else{          //ID found successfully
                        partialCardReads = 0;
                        Log.i(TAG, "Card successfully found in list");
                        //Display confirmation message after card swipe is successfully registered
                        toastMessage = cardContents.trim() + toastMessage;
                    }

                    //Display message as a toast.
                    statusUpdater.post(new Runnable() {
                        @Override
                        public void run(){
                            Toast.makeText(MainActivity.this, toastMessage, Toast.LENGTH_LONG).show();
                            Log.i(TAG, "Attempted to make toast indicating status.");
                        }

                    });
                } else {
                    Log.e(TAG, "CheckThread Socket failed to connect.");
                }

            } catch (Exception e) {
                Log.e(TAG, e.getMessage() + "\nError while trying to connect socket - CheckThread");
            }

        }
    }

    /*This code will only be executed if the connection failed after the button press.
        Thus, it is only executed if was bluetooth connected properly
        but now no longer has connection.
        Written by Brandon Atwal
    */
    private void connectionInterrupted(){
        tvStatus.setText("Bluetooth connection no longer detected. Restart both apps and try again.");
        Log.i(TAG, "Updated UI: Bluetooth Connection Interrupted.");
    }

    /*  Sends a single string to Attend
        Written by Brandon Atwal and Jacob Danel
    */
    private void manageConnectedSocket(BluetoothSocket socket, String input) throws IOException {
        Log.i(TAG, "Attempting to send input to desktop...");

        // Turn the input string into bytes, then write to the output stream.
        try {
            OutputStream outputStream = socket.getOutputStream();
            byte[] testInputBytes = input.getBytes();
            outputStream.write(testInputBytes);
            Log.i(TAG, "SENT id " + input);
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

}
