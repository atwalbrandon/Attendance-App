Welcome to the Attendance System!

To install, just copy all of the files from the Box folder to a folder
on your computer called Attend.  I keep it in H:\Attend so it is available
no matter what computer I'm using.  There are also some defaults that make
this advisable.  Once you have "installed" the program, double-click on
Attend.exe to run it.  That's it.

The "database" for this program is a series of Excel spreadsheets of your
class roster such as can be downloaded from eLearning or Coursebook,
described in more detail below.

You must have a file called Classes.txt in the same directory as the
program or in H:\Attend.  This contains the fully-qualified names of the
spreadsheets for each of your classes, a tab, the name of the class, a
tab, and the start time of the class based on a 24-hour clock.  When the
program opens, you'll be able to pick one of these classes, upon which
you will be shown the names and attendance history of all students.  You
can use the program to maintain this file.

Taking Attendance.

This is generally done by swiping the student's Comet card through a
magnetic strip reader.  When you create the spreadsheets, you won't have
the info from the card.  The program will search for the UTD ID in the
card information and, if it finds it, will associate that card with the
student.  If this doesn't work you can always manually associate the card
by clicking on the blank card ID column.  When someone is entered as
present, the name is highlighed in light blue and the time at which they
signed in appears in the column under the date.  These are also highlighted
so you can see who just got marked as present.  The program plays a short
"ding' sound.

You can also mark someone present by clicking on the cell next to their
name in the current date column.

Students will occasionally get a new Comet card.  If this happens, the
program won't find the ID, but you can right-click on the Card ID to get
a context menu.  One of the options is to replace the Card ID with the
one just entered.

The Excel workbook must have a worksheet called Attend.  You can download
this from Coursebook or eLearning, then modify it as follows:
  Column A -- The Card ID, which initially will be blank.  You must add
    this, with column header Card ID
  Column B -- The student's NetID (Column header NetID)
  Column C -- The student's UTD ID (Column header Student ID; MUST BE
    FORMATTED as TEXT)
  Column C -- First name
  Column D -- Middle name or initial
  Column E -- Last name
Leave all other columns empty; they will be filled in with attendance
data by the program.  Note that the order of the columns is not important,
and is not the same for eLearning and Coursebook.  Either will work.

Written by John Cole at The University of Texas at Dallas, with thanks
to Les Arnold for valuable feedback during development and for finding
the magnetic strip readers.  Initial version escaped on October 18, 2016.
Most recent version on February 8, 2022.